/* This file is part of the dosbox-automation Project.
   License: freeware, the UniMenu licence in unimenu.txt.
   Contact: dosbox-automation-project@trinity2k.net */

#include "port.h"
#include <conio.h>

int port_detect(void)
{
    return (inp(PORT_CMD) == PORT_SIGNATURE) ? 1 : 0;
}

unsigned port_receive_menu(char *buf, unsigned max_len)
{
    unsigned len = 0;

    /* After 0x13 the command port reads the signature while bytes
       remain and CMD_MENU_DATA_END after the last one. The loop stops
       at max_len whatever the port says. */
    outp(PORT_CMD, CMD_MENU_DATA_BEGIN);
    while (len < max_len && inp(PORT_CMD) == PORT_SIGNATURE)
        buf[len++] = (char)inp(PORT_DATA);
    outp(PORT_CMD, CMD_MENU_DATA_END);

    return len;
}

void port_send_choice(unsigned char entry)
{
    outp(PORT_CMD, CMD_CHOICE_BEGIN);
    outp(PORT_DATA, entry);
    outp(PORT_CMD, CMD_CHOICE_COMMIT);
}

void port_send_cancel(void)
{
    outp(PORT_CMD, CMD_CHOICE_CANCEL);
}
