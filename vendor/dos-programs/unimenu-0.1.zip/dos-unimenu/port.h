/* This file is part of the dosbox-automation Project.
   License: freeware, the UniMenu licence in unimenu.txt.
   Contact: dosbox-automation-project@trinity2k.net */

#ifndef UNIMENU_PORT_H
#define UNIMENU_PORT_H

#define PORT_CMD  0x3E0
#define PORT_DATA 0x3E1

#define CMD_MENU_DATA_BEGIN 0x13
#define CMD_MENU_DATA_END   0x14
#define CMD_CHOICE_BEGIN    0x10
#define CMD_CHOICE_COMMIT   0x11
#define CMD_CHOICE_CANCEL   0x12

#define PORT_SIGNATURE 0x4F

/* 50 entries of exe, args and label fit with room to spare. */
#define MENU_BUF_MAX 8192

/* Returns 1 if the engine answers on the menu port. */
int port_detect(void);

/* Receives the menu into buf, at most max_len bytes, and ends the
   transfer. Returns the byte count, 0 when the engine has no menu. */
unsigned port_receive_menu(char *buf, unsigned max_len);

/* Sends the number of the chosen entry, as the engine numbered it. */
void port_send_choice(unsigned char entry);

/* Sends cancel (ESC). */
void port_send_cancel(void);

#endif
