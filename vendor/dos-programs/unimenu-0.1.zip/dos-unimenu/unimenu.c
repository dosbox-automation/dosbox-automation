/* This file is part of the dosbox-automation Project.
   License: freeware, the UniMenu licence in unimenu.txt.
   Contact: dosbox-automation-project@trinity2k.net */

#include "dostui.h"
#include "dostui_kbd.h"
#include "port.h"
#include <string.h>
#include <i86.h>

#define VERSION_STR  "UniMenu v0.1"
#define PART_NUMBER  "SJ-ACC-0660"

#define MAX_ENTRIES  50
#define MAX_LABEL    61
#define MAX_EXE      80
#define MAX_TITLE    77

#define CAT_GAME   0
#define CAT_SETUP  1
#define CAT_OTHER  2
#define CAT_CONF   3

/* FNV-1a hashes, so the hidden names are not plaintext in the binary */

#define FNV_OFFSET 2166136261UL
#define FNV_PRIME  16777619UL

static unsigned long fnv1a(const char *s)
{
    unsigned long h = FNV_OFFSET;
    while (*s) {
        unsigned char c = (unsigned char)*s++;
        if (c >= 'a' && c <= 'z')
            c -= 32;
        h ^= c;
        h *= FNV_PRIME;
    }
    return h;
}

/* gen_hashes.py output for hidden_names.inc; make check compares them */
static const unsigned long hidden_hashes[] = {
    0x0B5888AFUL, /* DOS4GW.EXE */
    0xE8D76BC4UL, /* CWSDPMI.EXE */
    0xD8B2CBDEUL, /* CWSDPMI.R0 */
    0xC2197D92UL, /* CWSDSTUB.EXE */
    0x0F38E833UL, /* PMODEW.EXE */
    0xC5764CF4UL, /* RTM.EXE */
    0xF67308F1UL, /* DPMI.EXE */
    0x3757085DUL, /* DOS32A.EXE */
    0x22FAD1CEUL, /* WDOSX.EXE */
    0xDA4B84A1UL, /* CAUSEWAY.EXE */
    0x0CBA83D6UL, /* PMODE.EXE */
    0x411A6EDBUL, /* STUB.EXE */
    0x43ABE9B6UL, /* UNIVBE.EXE */
    0x1A2A4F74UL, /* SCITECH.EXE */
    0x94388F06UL, /* VBETEST.EXE */
    0x8AC41F0FUL, /* MOUSE.COM */
    0xCDBEA4D6UL, /* CTMOUSE.COM */
    0x1428411FUL, /* CTMOUSE.EXE */
    0x2DD87C2AUL, /* GMOUSE.COM */
    0xE11C6118UL, /* PKUNZIP.EXE */
    0xF9F747EDUL, /* PKZIP.EXE */
    0x5F920D7EUL, /* ARJ.EXE */
    0xA8289456UL, /* LHA.EXE */
    0x2DD71399UL, /* LHARC.EXE */
    0x9C949E79UL, /* ORDER.EXE */
    0x3A9A26E4UL, /* ORDERFRM.EXE */
    0xC1FB128DUL, /* VENDOR.EXE */
    0x6AEE2166UL, /* CATALOG.EXE */
    0x0356CA0EUL, /* REGISTER.EXE */
    0x24754D59UL, /* REGFORM.EXE */
    0x058994C9UL, /* README.EXE */
    0x3C0B1CC8UL, /* README.COM */
    0x1A00F4DEUL, /* HELPME.EXE */
    0xE36B4CF7UL, /* EXIST.COM */
    0x107E7E59UL, /* RESETDSK.COM */
    0x05F862EBUL, /* MAKEPATH.COM */
    0
};

/* The list holds bare file names: the check looks at the last path
   component of the exe line, without any arguments after it. */
static int is_hidden(const char *exe_line)
{
    char name[13];
    const char *start = exe_line;
    const char *p;
    unsigned long h;
    const unsigned long *hp;
    int n = 0;

    for (p = exe_line; *p && *p != ' '; p++) {
        if (*p == '\\')
            start = p + 1;
    }
    for (p = start; *p && *p != ' ' && n < (int)sizeof(name) - 1; p++)
        name[n++] = *p;
    name[n] = '\0';

    if (name[0] == '_')
        return 1;

    h = fnv1a(name);
    for (hp = hidden_hashes; *hp; hp++) {
        if (*hp == h)
            return 1;
    }
    return 0;
}


struct menu_entry {
    char label[MAX_LABEL];
    char exe[MAX_EXE];
    int category;
    /* the engine's number for the entry, counted before hiding */
    unsigned char index;
};

struct menu {
    char title[MAX_TITLE];
    struct menu_entry entries[MAX_ENTRIES];
    int count;
};


static int next_line(const char *buf, unsigned len, unsigned *pos,
                     char *out, int out_max)
{
    int n = 0;
    while (*pos < len && buf[*pos] != '\n') {
        if (n < out_max - 1)
            out[n++] = buf[*pos];
        (*pos)++;
    }
    if (*pos < len)
        (*pos)++;
    out[n] = '\0';

    if (n > 0 && out[n - 1] == '\r')
        out[--n] = '\0';

    return n;
}

static int parse_category(const char *line)
{
    if (strcmp(line, "[GAME]") == 0)  return CAT_GAME;
    if (strcmp(line, "[SETUP]") == 0) return CAT_SETUP;
    if (strcmp(line, "[OTHER]") == 0) return CAT_OTHER;
    if (strcmp(line, "[CONF]") == 0)  return CAT_CONF;
    return -1;
}

/* Every [CATEGORY] block is one engine entry, three lines long; hidden
   entries are counted and skipped so the numbers stay the engine's. */
static void parse_menu(const char *buf, unsigned len, struct menu *m)
{
    unsigned pos = 0;
    unsigned entry_no = 0;
    char line[128];
    char exe[MAX_EXE];

    memset(m, 0, sizeof(*m));

    next_line(buf, len, &pos, m->title, MAX_TITLE);
    next_line(buf, len, &pos, line, sizeof(line)); /* drive */
    next_line(buf, len, &pos, line, sizeof(line));

    while (pos < len && m->count < MAX_ENTRIES && entry_no < 256) {
        int cat;

        next_line(buf, len, &pos, line, sizeof(line));
        cat = parse_category(line);
        if (cat < 0)
            continue;

        next_line(buf, len, &pos, exe, MAX_EXE);
        next_line(buf, len, &pos, line, sizeof(line));

        if (exe[0] != '\0' && !is_hidden(exe)) {
            struct menu_entry *e = &m->entries[m->count++];
            strcpy(e->exe, exe);
            strncpy(e->label, line, MAX_LABEL - 1);
            e->label[MAX_LABEL - 1] = '\0';
            e->category = cat;
            e->index = (unsigned char)entry_no;
        }
        entry_no++;
    }
}


static int box_left;
static int box_right;
static int entry_row;
static int visible;

static unsigned char a_bg;
static unsigned char a_box;
static unsigned char a_title;
static unsigned char a_highlight;
static unsigned char a_footer;

static void init_attrs(void)
{
    a_bg        = dostui_attr(DOSTUI_C_NORMAL, DOSTUI_M_NORMAL);
    a_box       = dostui_attr(DOSTUI_C_BOX, DOSTUI_M_BOX);
    a_title     = dostui_attr(DOSTUI_C_TITLE, DOSTUI_M_TITLE);
    a_highlight = dostui_attr(DOSTUI_C_HIGHLIGHT, DOSTUI_M_REVERSE);
    a_footer    = dostui_attr(DOSTUI_C_FOOTER, DOSTUI_M_FOOTER);
}

static void draw_entry(const struct menu *m, int idx, int row, int selected)
{
    unsigned char attr = selected ? a_highlight : a_box;
    int width = box_right - box_left - 1;
    char line[80];
    const char *p;
    int n = 2;

    memset(line, ' ', sizeof(line));
    for (p = m->entries[idx].label; *p && n < width - 1; p++)
        line[n++] = *p;
    if (n < width - 4) {
        line[n++] = ' ';
        line[n++] = '(';
        for (p = m->entries[idx].exe; *p && n < width - 2; p++)
            line[n++] = *p;
        line[n++] = ')';
    }
    line[width] = '\0';
    dostui_puts(row, box_left + 1, attr, line);
}

/* Arrows in the right border say there is more above or below. */
static void draw_entries(const struct menu *m, int sel, int top)
{
    int i;
    for (i = 0; i < visible; i++)
        draw_entry(m, top + i, entry_row + i, top + i == sel);
    dostui_putch(entry_row, box_right, a_box,
                 top > 0 ? (char)0x18 : (char)0xBA);
    dostui_putch(entry_row + visible - 1, box_right, a_box,
                 top + visible < m->count ? (char)0x19 : (char)0xBA);
}

static void draw_frame(const struct menu *m)
{
    int scr_cols = dostui_columns();
    int scr_rows = dostui_rows();
    int box_width = 60;
    int box_top = 3;
    int bottom;

    init_attrs();
    dostui_clear(a_bg);

    {
        int tlen = (int)strlen(m->title);
        int tc = (scr_cols - tlen) / 2;
        if (tc < 0) tc = 0;
        dostui_puts(1, tc, a_title, m->title);
    }

    if (box_width > scr_cols - 4)
        box_width = scr_cols - 4;
    box_left = (scr_cols - box_width) / 2;
    box_right = box_left + box_width - 1;

    /* title, gap, top border, entries, separator, footer, bottom
       border and the version line take the rest of the screen */
    visible = scr_rows - box_top - 6;
    if (visible > m->count)
        visible = m->count;
    entry_row = box_top + 1;
    bottom = entry_row + visible + 2;

    dostui_box(box_top, box_left, bottom, box_right, a_box, a_box);
    dostui_hline(bottom - 2, box_left, box_right, a_box);
    {
        const char *keys = "ENTER Start | ESC Exit | UP/DOWN Move";
        if ((int)strlen(keys) > box_width - 3)
            keys = "ENTER Start | ESC Exit";
        dostui_puts(bottom - 1, box_left + 2, a_box, keys);
    }

    dostui_puts(scr_rows - 1, 1, a_footer,
                VERSION_STR "  PN: " PART_NUMBER
                "    (c) 2026 dosbox-automation");
}


static void say(const char *text)
{
    union REGS r;
    memset(&r, 0, sizeof(r));
    for (; *text; text++) {
        r.h.ah = 0x0E;
        r.h.al = (unsigned char)*text;
        r.h.bh = 0;
        r.h.bl = 0x07; /* foreground colour in graphics modes (RBIL INT 10/AH=0Eh) */
        int86(0x10, &r, &r);
    }
}

static void leave_screen(void)
{
    dostui_clear(0x07);
    dostui_cursor(0, 0);
    dostui_cursor_restore();
}


static char buf[MENU_BUF_MAX];
static struct menu m;

int main(void)
{
    unsigned len;
    int sel = 0;
    int top = 0;

    len = port_detect() ? port_receive_menu(buf, MENU_BUF_MAX) : 0;
    if (len > 0)
        parse_menu(buf, len, &m);
    if (m.count == 0) {
        if (len > 0) {
            port_send_cancel();
            say("UniMenu: nothing to start in this menu.\r\n");
        } else {
            say("UniMenu is started by dosbox-automation.\r\n");
        }
        return 1;
    }

    /* nothing to choose between once the hidden names are gone */
    if (m.count == 1) {
        port_send_choice(m.entries[0].index);
        return 0;
    }

    if (dostui_init() != 0) {
        port_send_cancel();
        say("UniMenu needs a text mode.\r\n");
        return 1;
    }

    dostui_cursor_hide();
    draw_frame(&m);
    draw_entries(&m, sel, top);

    for (;;) {
        int key = dostui_getkey();
        switch (key) {
        case DOSTUI_KEY_UP:   if (sel > 0) sel--; break;
        case DOSTUI_KEY_DOWN: if (sel < m.count - 1) sel++; break;
        case DOSTUI_KEY_PGUP: sel -= visible; break;
        case DOSTUI_KEY_PGDN: sel += visible; break;
        case DOSTUI_KEY_HOME: sel = 0; break;
        case DOSTUI_KEY_END:  sel = m.count - 1; break;
        case DOSTUI_KEY_ENTER:
            leave_screen();
            port_send_choice(m.entries[sel].index);
            return 0;
        case DOSTUI_KEY_ESC:
            leave_screen();
            port_send_cancel();
            return 0;
        default:
            continue;
        }
        if (sel < 0) sel = 0;
        if (sel > m.count - 1) sel = m.count - 1;
        if (sel < top) top = sel;
        if (sel >= top + visible) top = sel - visible + 1;
        draw_entries(&m, sel, top);
    }
}
