/* This file is part of the dosbox-automation Project.
   License: GPL-3.0-or-later; built into UniMenu, the UniMenu licence.
   Contact: dosbox-automation-project@trinity2k.net */

#include "dostui.h"
#include <dos.h>
#include <string.h>

static unsigned far *vram;
static int cols = 80;
static int rows = 25;
static int mda  = 0;
static unsigned char video_mode = 3;
static unsigned saved_shape = 0;
static int shape_saved = 0;

/* 40:84 is kept by EGA and later BIOSes only; INT 10h AH=12h BL=10h
   leaves BL unchanged on older adapters (RBIL INT 10/AH=12h/BL=10h). */
static int ega_bios(void)
{
    union REGS r;
    memset(&r, 0, sizeof(r));
    r.h.ah = 0x12;
    r.h.bl = 0x10;
    int86(0x10, &r, &r);
    return r.h.bl != 0x10;
}

int dostui_init(void)
{
    unsigned char far *bda_mode = (unsigned char far *)MK_FP(0x0040, 0x0049);
    unsigned char far *bda_cols = (unsigned char far *)MK_FP(0x0040, 0x004A);
    unsigned char far *bda_rows = (unsigned char far *)MK_FP(0x0040, 0x0084);
    unsigned char mode = *bda_mode;
    video_mode = mode;

    if (mode > 3 && mode != 7)
        return -1;

    cols = *bda_cols;
    if (cols < 40 || cols > 132)
        cols = 80;

    rows = 25;
    if (ega_bios()) {
        unsigned char r = *bda_rows;
        if (r > 0 && r < 100)
            rows = r + 1;
    }

    if (mode == 7) {
        vram = (unsigned far *)MK_FP(0xB000, 0x0000);
        mda = 1;
    } else {
        vram = (unsigned far *)MK_FP(0xB800, 0x0000);
        mda = 0;
    }

    return 0;
}

int dostui_columns(void) { return cols; }
int dostui_rows(void)    { return rows; }
int dostui_is_mda(void)  { return mda; }

unsigned char dostui_attr(unsigned char colour_attr,
                          unsigned char mda_attr)
{
    return mda ? mda_attr : colour_attr;
}

void dostui_puts(int row, int col, unsigned char attr,
                 const char *text)
{
    unsigned far *p;
    if (row < 0 || row >= rows || col < 0 || col >= cols)
        return;
    p = vram + row * cols + col;
    while (*text && col < cols) {
        *p++ = ((unsigned)attr << 8) | (unsigned char)*text++;
        col++;
    }
}

void dostui_putch(int row, int col, unsigned char attr, char ch)
{
    if (row >= 0 && row < rows && col >= 0 && col < cols)
        *(vram + row * cols + col) =
            ((unsigned)attr << 8) | (unsigned char)ch;
}

void dostui_clear(unsigned char attr)
{
    unsigned w = ((unsigned)attr << 8) | ' ';
    unsigned far *p = vram;
    int i, total = rows * cols;
    for (i = 0; i < total; i++)
        *p++ = w;
}

void dostui_cursor(int row, int col)
{
    union REGS r;
    r.h.ah = 0x02;
    r.h.bh = 0;
    r.h.dh = (unsigned char)row;
    r.h.dl = (unsigned char)col;
    int86(0x10, &r, &r);
}

/* AMI 386 and AST 386 BIOSes lock up unless AL holds the current
   mode (RBIL INT 10/AH=01h). */
static void set_cursor_shape(unsigned shape)
{
    union REGS r;
    r.h.ah = 0x01;
    r.h.al = video_mode;
    r.x.cx = shape;
    int86(0x10, &r, &r);
}

/* The shape comes from the BDA: many BIOSes answer AH=03h with the colour
   default when a monochrome display is attached (RBIL INT 10/AH=03h). */
void dostui_cursor_hide(void)
{
    unsigned far *bda_shape = (unsigned far *)MK_FP(0x0040, 0x0060);
    saved_shape = *bda_shape;
    shape_saved = 1;
    /* CH bits 6-5 = 01: invisible (RBIL INT 10/AH=01h, table 00013) */
    set_cursor_shape(0x2000);
}

void dostui_cursor_restore(void)
{
    if (!shape_saved)
        return;
    set_cursor_shape(saved_shape);
    shape_saved = 0;
}

void dostui_fill(int row, int col_start, int col_end,
                 char ch, unsigned char attr)
{
    unsigned w = ((unsigned)attr << 8) | (unsigned char)ch;
    unsigned far *p;
    int c;
    if (row < 0 || row >= rows) return;
    if (col_start < 0) col_start = 0;
    if (col_end >= cols) col_end = cols - 1;
    p = vram + row * cols + col_start;
    for (c = col_start; c <= col_end; c++)
        *p++ = w;
}

void dostui_box(int top, int left, int bottom, int right,
                unsigned char border_attr, unsigned char fill_attr)
{
    int r, c;

    dostui_putch(top, left, border_attr, (char)0xC9);
    dostui_putch(top, right, border_attr, (char)0xBB);
    dostui_putch(bottom, left, border_attr, (char)0xC8);
    dostui_putch(bottom, right, border_attr, (char)0xBC);
    for (c = left + 1; c < right; c++) {
        dostui_putch(top, c, border_attr, (char)0xCD);
        dostui_putch(bottom, c, border_attr, (char)0xCD);
    }
    for (r = top + 1; r < bottom; r++) {
        dostui_putch(r, left, border_attr, (char)0xBA);
        dostui_putch(r, right, border_attr, (char)0xBA);
        dostui_fill(r, left + 1, right - 1, ' ', fill_attr);
    }
}

void dostui_hline(int row, int left, int right,
                  unsigned char attr)
{
    int c;
    dostui_putch(row, left, attr, (char)0xCC);
    dostui_putch(row, right, attr, (char)0xB9);
    for (c = left + 1; c < right; c++)
        dostui_putch(row, c, attr, (char)0xCD);
}
