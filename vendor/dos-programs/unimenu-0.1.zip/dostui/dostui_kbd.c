/* This file is part of the dosbox-automation Project.
   License: GPL-3.0-or-later; built into UniMenu, the UniMenu licence.
   Contact: dosbox-automation-project@trinity2k.net */

#include "dostui_kbd.h"
#include <conio.h>

int dostui_getkey(void)
{
    int key = getch();
    if (key == 0 || key == 0xE0) {
        key = getch();
        switch (key) {
        case 72: return DOSTUI_KEY_UP;
        case 80: return DOSTUI_KEY_DOWN;
        case 71: return DOSTUI_KEY_HOME;
        case 79: return DOSTUI_KEY_END;
        case 73: return DOSTUI_KEY_PGUP;
        case 81: return DOSTUI_KEY_PGDN;
        default: return 0;
        }
    }
    return key;
}
