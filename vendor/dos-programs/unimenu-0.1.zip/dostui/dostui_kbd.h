/* This file is part of the dosbox-automation Project.
   License: GPL-3.0-or-later; built into UniMenu, the UniMenu licence.
   Contact: dosbox-automation-project@trinity2k.net */

#ifndef DOSTUI_KBD_H
#define DOSTUI_KBD_H

#define DOSTUI_KEY_UP    0x100
#define DOSTUI_KEY_DOWN  0x101
#define DOSTUI_KEY_HOME  0x102
#define DOSTUI_KEY_END   0x103
#define DOSTUI_KEY_PGUP  0x104
#define DOSTUI_KEY_PGDN  0x105
#define DOSTUI_KEY_ENTER 0x0D
#define DOSTUI_KEY_ESC   0x1B

/* Blocking key read. Returns ASCII for normal keys, DOSTUI_KEY_*
   constants for extended keys. */
int dostui_getkey(void);

#endif
