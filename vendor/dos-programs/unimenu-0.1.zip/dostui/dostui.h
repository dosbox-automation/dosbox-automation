/* This file is part of the dosbox-automation Project.
   License: GPL-3.0-or-later; built into UniMenu, the UniMenu licence.
   Contact: dosbox-automation-project@trinity2k.net */

#ifndef DOSTUI_H
#define DOSTUI_H

/* Returns 0 on success, -1 if the current mode is not a text mode.
   Must be called before any other dostui function. */
int dostui_init(void);

/* Screen geometry (valid after dostui_init). */
int dostui_columns(void);
int dostui_rows(void);
int dostui_is_mda(void);

/* mda_attr on a monochrome adapter, colour_attr otherwise. */
unsigned char dostui_attr(unsigned char colour_attr,
                          unsigned char mda_attr);

void dostui_clear(unsigned char attr);

/* Move the hardware cursor (INT 10h AH=02h, page 0). */
void dostui_cursor(int row, int col);

/* Hide the hardware cursor and keep its shape for dostui_cursor_restore. */
void dostui_cursor_hide(void);

/* Give back the shape dostui_cursor_hide kept. */
void dostui_cursor_restore(void);

/* Clips at the right edge. */
void dostui_puts(int row, int col, unsigned char attr,
                 const char *text);

void dostui_putch(int row, int col, unsigned char attr, char ch);

/* col_end is inclusive. */
void dostui_fill(int row, int col_start, int col_end,
                 char ch, unsigned char attr);

/* Double-line border. */
void dostui_box(int top, int left, int bottom, int right,
                unsigned char border_attr, unsigned char fill_attr);

/* T-junction characters at the box edges. */
void dostui_hline(int row, int left, int right, unsigned char attr);

/* Colour-mode attributes (augra-setup style). */
#define DOSTUI_C_NORMAL    0x17  /* white on blue */
#define DOSTUI_C_BOX       0x70  /* black on light gray */
#define DOSTUI_C_HIGHLIGHT 0x1F  /* bright white on blue */
#define DOSTUI_C_TITLE     0x1F  /* bright white on blue */
#define DOSTUI_C_FOOTER    0x18  /* dark gray on blue */

/* MDA attributes. */
#define DOSTUI_M_NORMAL    0x07
#define DOSTUI_M_HIGHLIGHT 0x0F
#define DOSTUI_M_BOX       0x07
#define DOSTUI_M_TITLE     0x0F
#define DOSTUI_M_FOOTER    0x07
#define DOSTUI_M_REVERSE   0x70

#endif
